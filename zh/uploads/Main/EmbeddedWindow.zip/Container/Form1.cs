﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;
using System.Windows.Forms.VisualStyles;

namespace Container
{
	public partial class Form1 : Form
	{
		[DllImport("User32.dll")]
		static extern bool MoveWindow(IntPtr handle, int x, int y, int width, int height, bool redraw);

		internal delegate int WindowEnumProc(IntPtr hwnd, IntPtr lparam);
		[DllImport("user32.dll")]
		internal static extern bool EnumChildWindows(IntPtr hwnd, WindowEnumProc func, IntPtr lParam);

		private Process process;
		private IntPtr unityHWND = IntPtr.Zero;

		public Form1()
		{
			InitializeComponent();

			try
			{
				process = new Process();
				process.StartInfo.FileName = "Child.exe";
				process.StartInfo.Arguments = "-parentHWND " + panel1.Handle.ToInt32() + " " + Environment.CommandLine;
				process.StartInfo.UseShellExecute = true;
				process.StartInfo.CreateNoWindow = true;

				process.Start();

				process.WaitForInputIdle();
				// Doesn't work for some reason ?!
				//unityHWND = process.MainWindowHandle;
				EnumChildWindows(panel1.Handle, WindowEnum, IntPtr.Zero);

				unityHWNDLabel.Text = "Unity HWND: 0x" + unityHWND.ToString("X8");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ".\nCheck if Container.exe is placed next to Child.exe.");
			}

		}
		private int WindowEnum(IntPtr hwnd, IntPtr lparam)
		{
			unityHWND = hwnd;
			return 0;
		}

		private void panel1_Resize(object sender, EventArgs e)
		{
			MoveWindow(unityHWND, 0, 0, panel1.Width, panel1.Height, true);
		}

		// Close Unity application
		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				process.CloseMainWindow();

				Thread.Sleep(1000);
				while (process.HasExited == false)
					process.Kill();
			}
			catch (Exception)
			{
				
			}
		}
	}
}
