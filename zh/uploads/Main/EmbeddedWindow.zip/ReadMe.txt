EmbeddeWindow example

Quickstart
* Open Unity project
* Build Windows Standalone application to Export directory, and name the executable as Child.exe
* Run Container.exe in Export directory
* You should see Windows Standalone application running inside Container application

Container.exe sources are located Container folder, you need Visual Studio 2010 or higher to build it.