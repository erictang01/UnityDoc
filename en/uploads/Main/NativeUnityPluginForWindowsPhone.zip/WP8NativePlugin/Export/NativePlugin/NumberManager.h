﻿#pragma once

namespace NativePlugin
{
    public ref class NumberManager sealed
    {
    public:
        NumberManager();

		static int AddNumbers(int first, int second);
    };
}
