﻿#include "pch.h"
#include "NumberManager.h"

using namespace NativePlugin;
using namespace Platform;

NumberManager::NumberManager()
{
}

int NumberManager::AddNumbers(int first, int second)
{
	return first + second;
}



